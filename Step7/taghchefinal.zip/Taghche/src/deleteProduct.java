/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Novin SOft
 */
public class deleteProduct {
    public void delete(long productID, String type){
         try{    
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver").newInstance();
            String url="jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
            Connection connect=DriverManager.getConnection(url);
            Statement state=connect.createStatement();
            String query="delete from allProducts where procuctID=%s";
            query= String.format(query, productID);
            state.execute(query);                  
            state.close();
            connect.close();
            }
            catch(IllegalAccessException | InstantiationException | ClassNotFoundException | SQLException ex){
                ex.printStackTrace();
            }
         
        if(type=="audio"){
            try{    
                Class.forName("net.ucanaccess.jdbc.UcanaccessDriver").newInstance();
                String url="jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
                Connection connect=DriverManager.getConnection(url);
                Statement state=connect.createStatement();
                String query="delete from audioBook where audioBooKID=%s";
                query= String.format(query, productID);
                state.execute(query);                  
                state.close();
                connect.close();
                }
            catch(IllegalAccessException | InstantiationException | ClassNotFoundException | SQLException ex){
                    ex.printStackTrace();
            }
        }
        else if(type=="text"){
            try{    
                Class.forName("net.ucanaccess.jdbc.UcanaccessDriver").newInstance();
                String url="jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
                Connection connect=DriverManager.getConnection(url);
                Statement state=connect.createStatement();
                String query="delete from textualBook where BooKID=%s";
                query= String.format(query, productID);
                state.execute(query);                  
                state.close();
                connect.close();
                }
            catch(IllegalAccessException | InstantiationException | ClassNotFoundException | SQLException ex){
                    ex.printStackTrace();
            }
        }
         
        
         
        System.out.println("product successfully deleted!");
    }
}

