
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import static javafx.application.Platform.exit;


public class UserProfile {
  
    private long accountCredit;
    private long customerID;
    
    
    public UserProfile( long customerID){
       this.customerID = customerID;
       menu();
    }
    
    public void menu(){
        
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("\nGozine Mord Nazar Ra Entekhab Konid:\n1-keteb hay man\n2-namayesh etelaat man\n3-afzayesh etabar\n4-royesh\n"
                + "5-ozviyat dar taghche binahayat\n6-modiriyat dastga ha\n7-payam hay man\n8-khoroj az barname\n");
        int choice = scanner.nextInt();
        switch(choice){
            case 1:
                Book book = new Book(customerID);
                break;
            case 2:
             CustomerAccount account = new CustomerAccount(customerID);
                break;
            case 3:
                increaseCredit();
                break;
            case 4:
               // royesh();
                break;
                
            case 5:
                byMembershipInTaghchebinahayat();
                break;
            case 6:
               // manageDiveces();
                break;
            case 7:
               myMessages();
                break;
            
            case 8:
                   while(true){
                        System.out.println("\naya az khoroj etminan darid?\n1-bale\n2-kheir\n");
                        int cho = scanner.nextInt();
                        if(cho == 1){
                            exit();
                            break;
                        }
                         else if(cho == 2){
                            System.out.println("\namaliyat motevagef shod.\n");
                            menu();
                            break;
                        }
                        else{
                            System.out.println("\nlotfa yek adad motabar vared konid:\n");
                        }
                   
                   
                    }     
                    break;
            default:
                System.out.println("\nlotfa yek adad motabar vard konid.\n");
                menu();
        }
    }
    
    public void increaseCredit(){
        Scanner scanner = new Scanner(System.in);
        this.accountCredit = accountCredit();
        System.out.println("\netebar feli shoma:" + this.accountCredit +"\n1-afzayesh hesab\n2-bazgasht\n3-khoroj az barname\n");
        int choice = scanner.nextInt();
        switch(choice){
            case 1:
                System.out.println("\nmeghdar mored nazar ra vared konid(baray khoroj 0 ra vared konid):\n");
                long increaseAmount = scanner.nextInt();
                if(increaseAmount == 0){
                    System.out.println("\namahiyat motevaghef shod.\n");
                    increaseCredit();
                }
                else{
                    increaseProcess(increaseAmount);
                }
                break;
                
            case 2:
                menu();
                break;
                
            case 3:
                   while(true){
               System.out.println("\naya az khoroj etminan darid?\n1-bale\n2-kheir\n");
               int cho = scanner.nextInt();
               if(cho == 1){
                    exit();
                    break;
               }
               else if(cho == 2){
                   System.out.println("\namaliyat motevagef shod.\n");
                   menu();
                   break;
               }
               else{
                  System.out.println("\nlotfa yek adad motabar vared konid:\n");
               }
                   
                   
               }     
                break;
                
            default :
                System.out.println("\nlotfa yek shomare motabar vared konid.\n");
                increaseCredit();
                
        }
      
    }
    
    public long accountCredit(){
        long customerId ;
       
        
        try{
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver").newInstance();
            String url="jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
            Connection connect=DriverManager.getConnection(url);
            Statement state=connect.createStatement();
            String query="select * from costumer";
            ResultSet result=state.executeQuery(query);
            while(result.next()){
                customerId=result.getLong("costumerID");  
             if(customerId == this.customerID){
                  this.accountCredit = result.getLong("accountCredit");
                }
            }
            
            state.close();
            connect.close();
        }
        catch(IllegalAccessException | InstantiationException | ClassNotFoundException | SQLException ex){
            ex.printStackTrace();
        }
        return accountCredit;
    }
    
    public void increaseProcess(long increaseAmount){
        this.accountCredit += increaseAmount;
        
        try{
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver").newInstance();
            String url = "jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "update costumer set accountCredit=%s WHERE costumerID = %s";
            query = String.format(query, this.accountCredit, this.customerID);       
            state.execute(query);       
            state.close();
            connect.close();
        }
        catch(IllegalAccessException | InstantiationException | ClassNotFoundException | SQLException ex){
            ex.printStackTrace();
        }
        System.out.println("\nafzayesh etebar movafagiyat amiz bood.\netebar jadid:" + this.accountCredit + "\n");
    }
    
    public void byMembershipInTaghchebinahayat(){
        boolean confirmed = true;
        Scanner scanner = new Scanner(System.in);
        System.out.println("\nnoe ozviyat ra entekhab konid:\n1-yek hafte(8000 toman)\n2-yek mahe(15000 toman)\n3-3 mahe(37000 toman)"
                + "\n4- 6 mahe (67000 toman)\n5- yek sale(120000 toman)\n6-bazgasht\n7-khoroj az barname");
        int choice = scanner.nextInt();
        long purchase = 0;
        switch(choice){
            case 1:
                purchase += 8000;
                break;
            case 2:
                 purchase += 15000;
                break;
            case 3:
                purchase += 37000;
                break;
            case 4:
                purchase += 67000;
                break;
            case 5 :
                purchase += 120000;
                break;
            case 6:
                menu();
                break;
            case 7:
                while(true){
                    System.out.println("\naya az khoroj etminan darid?\n1-bale\n2-kheir\n");
                    int cho = scanner.nextInt();
                    if(cho == 1){
                        exit();
                        break;
                    }
                    else if(cho == 2){
                        System.out.println("\namaliyat motevagef shod.\n");
                        menu();
                        break;
                    }
                    else{
                        System.out.println("\nlotfa yek adad motabar vared konid:\n");
                    }
                   
                   
                }     
              break;
            default:
                System.out.println("\nlotfa yek adad motabar vared konid.\n");
                confirmed = false;
                byMembershipInTaghchebinahayat();
                
        }
        if(confirmed == true)
            buymemberShip(purchase);
       
    }
    
    
    public void buymemberShip(long purchase){
        Scanner scanner = new Scanner(System.in);
        this.accountCredit = accountCredit();
         System.out.println("mojodi feli shoma:" + accountCredit + "\n");
        if(accountCredit>=purchase){
           System.out.println("\naya mayel be kharid ozviyat hastid?\n1-bale\n2-kheir\n");
           int choice = scanner.nextInt();
           if(choice == 1){
               buyMembershipProcess(purchase);
           }
           else if(choice == 2){
               
           }
           else{
               System.out.println("\nlotfan yek adad motavar vared koni.\n");
               buymemberShip(purchase);
           }
        }
        else {
            System.out.println("\nmojodi shoma baray kharid in ozviyat kafi nist.\naya mayel be afzayesh etebar hastid?\n1-bale\n2-khieyn");
            int choice = scanner.nextInt();
            if(choice ==1){
                increaseCredit();
                byMembershipInTaghchebinahayat();
            }
            else if(choice == 2){
                System.out.println("\namaliyat motevaghef shod.\n");
                byMembershipInTaghchebinahayat();
            }
            else{
                System.out.println("\nlotfan yek adad motavar vared koni.\n");
                buymemberShip(purchase);
            }
        }
        
    }
    
    public void buyMembershipProcess(long purchase){
        
        this.accountCredit -= purchase;
        
        try{
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver").newInstance();
            String url = "jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "update costumer set accountCredit=%s WHERE costumerID = %s";
            query = String.format(query, this.accountCredit , this.customerID);       
            state.execute(query);       
            state.close();
            connect.close();
        }
        catch(IllegalAccessException | InstantiationException | ClassNotFoundException | SQLException ex){
            ex.printStackTrace();
        }
        System.out.println("\nkharid movafagiyat amiz bood.\netebar jadid:" + this.accountCredit + "\n");
    }
    
     public void myMessages(){
         
         System.out.println("payamhay shoma:\n");
          try{
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver").newInstance();
            String url="jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
            Connection connect=DriverManager.getConnection(url);
            Statement state=connect.createStatement();
            String query="select * from messages  WHERE customerID = '%s' ";
            query = String.format(query, Long.toString(this.customerID));
            ResultSet result=state.executeQuery(query);
            while(result.next()){
                System.out.println("payam:"+result.getString("messageText")+ "    kod takhfif:" + result.getString("discountCode")+"\n"  );
                 
            }
           
            
            state.close();
            connect.close();
        }
        catch(IllegalAccessException | InstantiationException | ClassNotFoundException | SQLException ex){
            ex.printStackTrace();
        }
          
         Scanner scanner = new Scanner(System.in);
        
         System.out.println("\n1-bazgasht\n2-khoroj az barname\n");
         int choice = scanner.nextInt();
         if(choice == 1){
             menu();
         }
         while(true){
          if(choice == 2){
             System.out.println("\naya az khoroj etminan darid?\n1-bale\n2-kheir\n");
             int cho = scanner.nextInt();
             if(cho == 1){
                exit();
                break;
             }
             else if(cho == 2)
             {
                 System.out.println("\namaliyat motevagef shod.\n");
                 menu();
                 break;
             }
             else{
                 
                 System.out.println("\nlotfa yek adad motabar vared konid:\n");
             }
         }
     }
     }
    
}
