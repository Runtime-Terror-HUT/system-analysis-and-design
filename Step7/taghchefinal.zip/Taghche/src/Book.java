
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Book
{
     static long costumerID;
     String BookId;
     String BookName;
     String BookShelfId;
     int Flag;

     public static Book Kh[] = new Book[100];
     public static int Countbook=0;
     static Scanner scanner = new Scanner(System.in);
     
     public Book(long costumerID){
         this.costumerID = costumerID;
         menu();
     }

    public void menu() {

        int Selection=0;

        while(Selection!=5 || Selection!=9)
        {
            System.out.println("\n * * * * * * * * * * * * * * *");
            System.out.println(" * 1.Show Shelfs               *");
            System.out.println(" * 2.Create Shelf              *");
            System.out.println(" * 3.Open Shelf                *");
            System.out.println(" * 4.Delete                    *");
            System.out.println(" * 5.Edit                      *");
            System.out.println(" * 6.EXIT                      *");
            System.out.println(" * * * * * * * * * * * * * * * *");
            System.out.print(" Selection : ");
            Selection = scanner.nextInt();

            switch (Selection)
            {
                case 1:
                   showBookShelfs();
                    break;
                case 2:
                   createBookShelfs();
                    break;
                case 3:
                     openShelf();
                    break;

                case 4:
                  deleteShelf();
                  break;
                case 5:
                   addComment();
                case 9:
                    break;
            }
        }
    }


    public static void showBookShelfs(){
        String bookShelfName= "";
        System.out.println("--------------------------------------------------------------------------------------------------");
        try{
            String url="jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
            String query = "SELECT bookShelfName FROM bookShelfs WHERE costumerID = " + 1;
            Connection connection = DriverManager.getConnection(url);
            Statement state = connection.createStatement();
            ResultSet result = state.executeQuery(query);
            while (result.next()) {
                bookShelfName = result.getString("bookShelfName");
                 System.out.println("bookShelfName: " + bookShelfName);
                 System.out.println("--------------------------------------------------------------------------------------------------");
            }
                 state.close();
                 connection.close();
        }catch(Exception e){
            System.out.println("system error");
        }
    }

    public static void createBookShelfs(){
        String url="jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
        String query = "INSERT INTO bookShelfs(bookShelfID , costumerID , bookShelfName)"
                       + " values(%s,'%s','%s')";
        String bookShelfName = "";
        RandomNumber number = new RandomNumber();
        long bookShelfID = Long.parseLong(number.random(5));
        System.out.println(bookShelfID);
        System.out.println("naam shelf ra vared konid:");
        scanner.nextLine();
        bookShelfName = scanner.nextLine();
                    try{
                        Connection connection = DriverManager.getConnection(url);
                        Statement state = connection.createStatement();
                        query = String.format(query,bookShelfID,costumerID,bookShelfName);
                        state.execute(query);
                        state.close();
                        connection.close();
                    }catch(Exception e){
                        System.out.println("system error");
                       }
        }



        public static void openShelf(){
            String selectedBookShelfName = "";
            String bookName = "";
            long bookShelfId = 0;
            showBookShelfs();
            System.out.println("\nnaam shelf mored nazar ra vared konid:");
            scanner.nextLine();
            selectedBookShelfName = scanner.nextLine();
            try{
                String url="jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
                Connection connection = DriverManager.getConnection(url);
                Statement state = connection.createStatement();
                String query1 = "SELECT bookShelfID FROM bookShelfs WHERE bookShelfs.bookShelfName = " + "\"" + selectedBookShelfName + "\"" + " AND bookShelfs.costumerID = " + 1 ;
                ResultSet result1 = state.executeQuery(query1);
                while (result1.next()) {
                     bookShelfId = result1.getLong("bookShelfID");
                }
                String query2 = "SELECT bookName FROM bookShelfBooks WHERE bookShelfBooks.bookShelfID = " + bookShelfId + " AND bookShelfBooks.customerID = " + 1;
                ResultSet result2 = state.executeQuery(query2);
                while (result2.next()) {
                     bookName = result2.getString("bookName");
                     System.out.println("bookName: " + bookName);
                     System.out.println("--------------------------------------------------------------------------------------------------");
                }
                     state.close();
                     connection.close();
            }catch(Exception e){
                System.out.println(e);
            }
        }

        public static void deleteShelf(){
            String selectedBookShelfName = "";
            showBookShelfs();
            System.out.println("\nnaam shelf mored nazar ra vared konid:");
            scanner.nextLine();
            selectedBookShelfName = scanner.nextLine();
            try{
                String url="jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
                Connection connection = DriverManager.getConnection(url);
                Statement state = connection.createStatement();
                PreparedStatement st = connection.prepareStatement("DELETE FROM bookShelfs WHERE bookShelfs.bookShelfName = ? AND bookShelfs.costumerID = ?");
                        st.setString(1,selectedBookShelfName);
                        st.setLong(2,1);
                        st.executeUpdate(); 
                        System.out.println("hazf movafagh");
                        state.close();
                        connection.close();
            }catch(Exception e){
                System.out.println("hazf namovafagh");
            }
        }



        public static void addComment() {
            long commentID;
            long bookID = 0;
            String commentText;
            String userName = "";
            String commentDate;
            String commentTime;
            String selectedBooKName;
            openShelf();    
            RandomNumber number = new RandomNumber();
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");  
            DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("HH:mm");  
            LocalDateTime now = LocalDateTime.now();  
            System.out.println(dtf.format(now));  
            commentDate = dtf.format(now);
            commentTime = dtf1.format(now);
            commentID = Long.parseLong(number.random(5));
            System.out.println(commentTime);
            System.out.println("naam ketab mored nazar baraye afzoodan comment ra vared konid:");
            selectedBooKName = scanner.nextLine();
            System.out.println("\nmatn comment ra vared konid:");
            commentText = scanner.nextLine();
            try{
                String url="jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
                Connection connection = DriverManager.getConnection(url);
                Statement state = connection.createStatement();
                String query1 = "SELECT * FROM costumer WHERE costumerID = " + 1;
                ResultSet result1 = state.executeQuery(query1);
                System.out.println(query1);

                while(result1.next()){
                    userName = result1.getString("userName");
                    System.out.println(userName);
                }
                 String query2 = "SELECT * FROM bookShelfBooks WHERE bookShelfBooks.bookName = " + "\"" + selectedBooKName + "\"" + " AND customerID = " + 1;
                 System.out.println(query2);
                 ResultSet result2 = state.executeQuery(query2);
                 while(result2.next()){
                    bookID = result2.getLong("bookID");
                } 
                System.out.println(bookID); 
                String query3 = "INSERT INTO comments(costumerID , commentID , commentText , userName , dateOfComment , timeOfComment , bookID , bookName , likesNumber , dislikesNumber)"
                + " values('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')";  
                query3 = String.format(query3,costumerID,commentID,commentText,userName,commentDate,commentTime,bookID,selectedBooKName,0,0);
                state.execute(query3);             
                connection.close();
                state.close();
                System.out.println("comment afzoode shod!");
            }catch(Exception e){
                System.out.println("comment afzoode nashod!");
            }
        }
    }
