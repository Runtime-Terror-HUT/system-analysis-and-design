import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;


public class CustomerAccount {
   private static long customerID;
   
   public CustomerAccount(long customerID){
       this.customerID = customerID;
       menu();
   }
   
   public static void menu(){
       Scanner scanner = new Scanner(System.in);
       System.out.println("\nGozine Mord Nazar Ra Entekhab Konid:\n1-namayesh profile\n2-virayesh profile");
       int choice = scanner.nextInt();
       switch(choice){
           case 1:
               showProfile();
               break;
            case 2:
               editProfile();
               break;
            default :
                System.out.println("\nlotfa yek adad motabar vared konid:\n");
                 menu();
       }
   }



   public static void showProfile(){
    String userName= "";
     String phoneNumber = "";
     String email = "";
    int accountCredit = 0;
    try{
        String url="jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
        String query = "SELECT * FROM costumer WHERE costumerID = " + customerID;
        Connection connection = DriverManager.getConnection(url);
        Statement state = connection.createStatement();
        ResultSet result = state.executeQuery(query);
        while (result.next()) {
             userName = result.getString("username");
             email = result.getString("email");
             phoneNumber = result.getString("phoneNumber");
             accountCredit = result.getInt("accountCredit");
        }
        System.out.println("userName: " + userName + "\n" + "email: " + email + "\n" + "phone number: " +phoneNumber + "\n" + "accountCredit: " + accountCredit);
        state.execute(query);
        state.close();
        connection.close();
    }
    catch(Exception e){
        System.out.println("System Error");
    }
   }
   
   void setCustomerID(int id){
        customerID = id;
       }


     public static void editProfile(){
        String userName= "";
        String phoneNumber = "";
        String email = "";
        String password = "";
        Scanner scanner = new Scanner(System.in);
        System.out.println("\nnam karbari jadid khod ra vared konid:\n");
        userName = scanner.nextLine();
        System.out.println("\nshomare jadid khod ra vared konid:\n");
        phoneNumber = scanner.nextLine();
        System.out.println("\nemail jadid khod ra vared konid:\n");
        email = scanner.nextLine();
        System.out.println("\npassword jadid khod ra vared konid:\n");
        password = scanner.nextLine();
        try{
            String url="jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "UPDATE costumer SET username = ? , email = ? , phoneNumber = ? , password = ? WHERE costumerID = " + customerID;
            PreparedStatement preparedStatement = connect.prepareStatement(query);
            preparedStatement.setString(1, userName);
            preparedStatement.setString(2, email);
            preparedStatement.setString(3, phoneNumber);
            preparedStatement.setString(4, password);
            preparedStatement.executeUpdate();   
            state.close();
            connect.close();
            System.out.println("\n Virayesh ba movafaghiat anjam shod\n) \n");
        }
        catch(Exception ex){
            ex.printStackTrace();
        }
     }
}

