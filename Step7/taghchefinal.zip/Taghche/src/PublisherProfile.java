
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class PublisherProfile{
    static long authorID;

    public PublisherProfile(){
        menu();
    }
    
    public static void menu(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("\nGozine Mord Nazar Ra Entekhab Konid:\n1-namayesh etelaat man\n2-namayesh ketab haye man\n3-virayesh ketab haye man\n4-hazf ketab haye man");
        int choice = scanner.nextInt();
        switch(choice){
            case 1:
                PublisherAccount account = new PublisherAccount();
                 break;
            case 2:
                showMyBooks();
                break;
            case 3:
                editBook();
                break;
            case 4:
                deleteBook();
                break;
               
             default :
                 System.out.println("\nlotfa yek adad motabar vared konid:\n");
                 menu();
             }
        }

        void setAuthorID(int id){
            authorID = id;
           }

        public static void showMyBooks(){
            String bookName= "";
            String publisher = "";
            String authorName = "";
            String translatorName = "";
            String publishYear= "";
            int price = 0;
            int numOfStars = 0;   
            System.out.println("--------------------------------------------------------------------------------------------------");
           try{
               String url="jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
               String query = "SELECT * FROM textualBook WHERE textualBook.authorID = " + authorID;
               String query1 = "SELECT * FROM audioBook WHERE audioBook.authorID = " + authorID;
               Connection connection = DriverManager.getConnection(url);
               Statement state = connection.createStatement();
               ResultSet result = state.executeQuery(query);
               ResultSet result1 = state.executeQuery(query1);

               while (result.next()) {
                    bookName = result.getString("bookName");
                    publisher = result.getString("publisher");
                    authorName = result.getString("authorName");
                    translatorName = result.getString("translatorName");
                    publishYear = result.getString("publishYear");
                    price = result.getInt("price");
                    numOfStars = result.getInt("numberOfStars");
                    System.out.println("bookName: " + bookName + "\n" + "publisher: " + publisher + "\n" + "authorName: " + authorName + "\n" + "translatorName: " + translatorName  +"\n" + "publishYear: " + publishYear +"\n" + "price: " + price +"\n" + "number of stars: " + numOfStars);
                    System.out.println("--------------------------------------------------------------------------------------------------");
               }

               while (result1.next()) {
                bookName = result1.getString("bookName");
                publisher = result1.getString("publisher");
                authorName = result1.getString("authorName");
                translatorName = result1.getString("translatorName");
                publishYear = result1.getString("publishYear");
                price = result1.getInt("price");
                numOfStars = result1.getInt("numberOfStars");
                System.out.println("bookName: " + bookName + "\n" + "publisher: " + publisher + "\n" + "authorName: " + authorName + "\n" + "translatorName: " + translatorName  +"\n" + "publishYear: " + publishYear +"\n" + "price: " + price +"\n" + "number of stars: " + numOfStars);
                System.out.println("--------------------------------------------------------------------------------------------------");
           }
               
               state.execute(query);
               state.close();
               connection.close();
           }
           catch(Exception e){
               System.out.println(e);
           }
          }



          public static void deleteBook(){
            int choice;
            int bookID = 0;
            int selectedBookID;
            int price = 0;
            int numOfStars = 0;
            String bookName= "";
            String publisher = "";
            String authorName = "";
            String translatorName = "";
            String publishYear= "";
            System.out.println("\nGozine Mord Nazar Ra Entekhab Konid:\n1-hazf ketab matni\n2-hazf ketab soti");
            Scanner scanner = new Scanner(System.in);
            choice = scanner.nextInt();
            System.out.println("--------------------------------------------------------------------------------------------------");
           try{
               String url="jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
               String query = "SELECT * FROM textualBook WHERE textualBook.authorID = " + authorID;
               String query1 = "SELECT * FROM audioBook WHERE audioBook.authorID = " + authorID;
               Connection connection = DriverManager.getConnection(url);
               Statement state = connection.createStatement();
                if(choice == 1){
                    ResultSet result = state.executeQuery(query);
               while (result.next()) {
                    bookID = result.getInt("bookID");
                    bookName = result.getString("bookName");
                    publisher = result.getString("publisher");
                    authorName = result.getString("authorName");
                    translatorName = result.getString("translatorName");
                    publishYear = result.getString("publishYear");
                    price = result.getInt("price");
                    numOfStars = result.getInt("numberOfStars");
                    System.out.println("bookID: " + bookID + "\n" + "bookName: " + bookName + "\n" + "publisher: " + publisher + "\n" + "authorName: " + authorName + "\n" + "translatorName: " + translatorName  +"\n" + "publishYear: " + publishYear +"\n" + "price: " + price +"\n" + "number of stars: " + numOfStars);
                    System.out.println("--------------------------------------------------------------------------------------------------");
               }
               System.out.println("\nid ketab mored nazar ra vared konid:");
               selectedBookID = scanner.nextInt();
                    try{
                        PreparedStatement st = connection.prepareStatement("DELETE FROM textualBook WHERE bookID = ?");
                        st.setInt(1,selectedBookID);
                        st.executeUpdate(); 
                        System.out.println("hazf movafagh");
                    }catch(Exception e){
                            System.out.println("hazf namovafagh");
                        }
            }else{
                ResultSet result1 = state.executeQuery(query1);
               while (result1.next()) {
                bookID = result1.getInt("audioBookID");
                bookName = result1.getString("bookName");
                publisher = result1.getString("publisher");
                authorName = result1.getString("authorName");
                translatorName = result1.getString("translatorName");
                publishYear = result1.getString("publishYear");
                price = result1.getInt("price");
                numOfStars = result1.getInt("numberOfStars");
                System.out.println("bookID: " + bookID + "\n" + "bookName: " + bookName + "\n" + "publisher: " + publisher + "\n" + "authorName: " + authorName + "\n" + "translatorName: " + translatorName  +"\n" + "publishYear: " + publishYear +"\n" + "price: " + price +"\n" + "number of stars: " + numOfStars);
                System.out.println("--------------------------------------------------------------------------------------------------");
           }
           System.out.println("\nid ketab mor  ed nazar ra vared konid:");
           selectedBookID = scanner.nextInt();
                try{
                    PreparedStatement st = connection.prepareStatement("DELETE FROM audioBook WHERE audioBookID = ?");
                    st.setInt(1,bookID);
                    st.executeUpdate(); 
                    System.out.println("hazf movafagh");
                }catch(Exception e){
                    System.out.println("hazf namovafagh");
                }
        }
               state.execute(query);
               state.close();
               connection.close();
            } 
           catch(Exception e){
               System.out.println(e);
           }
          }
    

          public static void editBook(){
            String url="jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
            int choice;
            System.out.println("\nGozine Mord Nazar Ra Entekhab Konid:\n1-virayesh ketab matni\n2-virayesh ketab soti");
            Scanner scanner = new Scanner(System.in);
            choice = scanner.nextInt();
            System.out.println("--------------------------------------------------------------------------------------------------");
            if(choice == 1){
                int selectedBookID;
                int price = 0;
                int numOfStars = 0;
                int numOfPages = 0;
                int bookID = 0;
                String bookName= "";
                String format= "";
                String priceOfPrintedVersion= "";
                String publishYear= "";
                String publisher = "";
                String authorName = "";
                String translatorName = "";
                String query = "SELECT * FROM textualBook WHERE textualBook.authorID = 1";
                try{         
                    Connection connect = DriverManager.getConnection(url);
                    Statement state = connect.createStatement();
                    ResultSet result = state.executeQuery(query);
                    while (result.next()) {
                        bookID = result.getInt("bookID");
                        bookName = result.getString("bookName");
                        publisher = result.getString("publisher");
                        authorName = result.getString("authorName");
                        translatorName = result.getString("translatorName");
                        publishYear = result.getString("publishYear");
                        price = result.getInt("price");
                        numOfStars = result.getInt("numberOfStars");
                        System.out.println("bookID: " + bookID + "\n" + "bookName: " + bookName + "\n" + "publisher: " + publisher + "\n" + "authorName: " + authorName + "\n" + "translatorName: " + translatorName  +"\n" + "publishYear: " + publishYear +"\n" + "price: " + price +"\n" + "number of stars: " + numOfStars);
                        System.out.println("--------------------------------------------------------------------------------------------------");
                   }
                   state.close();
                }catch(Exception e){
                    System.out.println(e);
                }
               System.out.println("\nid ketab mored nazar ra vared konid:");
               selectedBookID = scanner.nextInt();
               scanner.nextLine(); 
               System.out.println("\nnam jadid ketab khod ra vared konid:\n");
               bookName = scanner.nextLine();
               System.out.println("\ngheimat version chapi jadid ra vared konid:\n");
               priceOfPrintedVersion = scanner.nextLine();
               System.out.println("\nformat jadid ra vared konid:\n");
               format = scanner.nextLine();
               System.out.println("\ntarikh enteshar jadid ra vared konid:\n");
               publishYear = scanner.nextLine();
               System.out.println("\nmontasher konande jadid ra vared konid:\n");
               publisher = scanner.nextLine();
               System.out.println("\nnevisande jadid ra vared konid:\n");
               authorName = scanner.nextLine();
               System.out.println("\nmotarjem jadid ra vared konid:\n");
               translatorName = scanner.nextLine();
               System.out.println("\ngheimat jadid ra vared konid:\n");
               price = scanner.nextInt();
               System.out.println("\ntedad safehat ra vared konid:\n");
               numOfPages = scanner.nextInt();
               System.out.println("\ntedad setare jadid ra vared konid:\n");
               numOfStars = scanner.nextInt();
               try{
                   Connection connect = DriverManager.getConnection(url);
                   String q = "UPDATE textualBook SET bookName = ? , price = ? , numberOfPages = ?, priceOfPrintedVersion = ? , format = ? , publishYear = ? , publisher = ? , authorName = ? , translatorName = ? , numberOfStars = ? WHERE bookID = " + selectedBookID;
                   PreparedStatement preparedStatement = connect.prepareStatement(q);
                   preparedStatement.setString(1, bookName);
                   preparedStatement.setInt(2, price);
                   preparedStatement.setInt(3, numOfPages);
                   preparedStatement.setString(4, priceOfPrintedVersion);
                   preparedStatement.setString(5, format);
                   preparedStatement.setString(6, publishYear);
                   preparedStatement.setString(7, publisher);
                   preparedStatement.setString(8, authorName);
                   preparedStatement.setString(9, translatorName);
                   preparedStatement.setInt(10, numOfStars);
                   preparedStatement.executeUpdate();   
                   System.out.println("\n Virayesh ba movafaghiat anjam shod\n");
                   connect.close();
               }
               catch(Exception ex){
                   ex.printStackTrace();
               }
             
            }else{
                int selectedBookID;
                int price = 0;
                int numOfStars = 0;
                int timeOfAudio = 0;
                int bookID = 0;
                String bookName= "";
                String format= "";
                String broadcasterName = "";
                String publishYear= "";
                String publisher = "";
                String authorName = "";
                String translatorName = "";
                String query = "SELECT * FROM audioBook WHERE audioBook.authorID = " + authorID;
                try{         
                    Connection connect = DriverManager.getConnection(url);
                    Statement state = connect.createStatement();
                    ResultSet result = state.executeQuery(query);
                    while (result.next()) {
                        bookID = result.getInt("audioBookID");
                        bookName = result.getString("bookName");
                        publisher = result.getString("publisher");
                        authorName = result.getString("authorName");
                        translatorName = result.getString("translatorName");
                        publishYear = result.getString("publishYear");
                        price = result.getInt("price");
                        numOfStars = result.getInt("numberOfStars");
                        System.out.println("bookID: " + bookID + "\n" + "bookName: " + bookName + "\n" + "publisher: " + publisher + "\n" + "authorName: " + authorName + "\n" + "translatorName: " + translatorName  +"\n" + "publishYear: " + publishYear +"\n" + "price: " + price +"\n" + "number of stars: " + numOfStars);
                        System.out.println("--------------------------------------------------------------------------------------------------");
                   }
                   state.close();
                }catch(Exception e){
                    System.out.println(e);
                }
               System.out.println("\nid ketab mored nazar ra vared konid:");
               selectedBookID = scanner.nextInt();
               scanner.nextLine(); 
               System.out.println("\nnam jadid ketab khod ra vared konid:\n");
               bookName = scanner.nextLine();
               System.out.println("\nformat jadid ra vared konid:\n");
               format = scanner.nextLine();
               System.out.println("\ntarikh enteshar jadid ra vared konid:\n");
               publishYear = scanner.nextLine();
               System.out.println("\nmontasher konande jadid ra vared konid:\n");
               publisher = scanner.nextLine();
               System.out.println("\nnevisande jadid ra vared konid:\n");
               authorName = scanner.nextLine();
               System.out.println("\nmotarjem jadid ra vared konid:\n");
               translatorName = scanner.nextLine();
               System.out.println("\nnaam pakhsh konande jadid ra vared konid:\n");
               broadcasterName = scanner.nextLine();
               System.out.println("\ngheimat jadid ra vared konid:\n");
               price = scanner.nextInt();
               System.out.println("\nzaman ketab soti ra vared konid:\n");
               timeOfAudio = scanner.nextInt();
               System.out.println("\ntedad setare jadid ra vared konid:\n");
               numOfStars = scanner.nextInt();
               try{
                   Connection connect = DriverManager.getConnection(url);
                   String q = "UPDATE audioBook SET bookName = ? , price = ? , timeOfAudio = ? , fileFormat = ? , publishYear = ? , publisher = ? , authorName = ? , translatorName = ? , broadcasterName = ? , numberOfStars = ? WHERE audioBookID = " + selectedBookID;
                   PreparedStatement preparedStatement = connect.prepareStatement(q);
                   preparedStatement.setString(1, bookName);
                   preparedStatement.setInt(2, price);
                   preparedStatement.setInt(3, timeOfAudio);
                   preparedStatement.setString(4, format);
                   preparedStatement.setString(5, publishYear);
                   preparedStatement.setString(6, publisher);
                   preparedStatement.setString(7, authorName);
                   preparedStatement.setString(8, translatorName);
                   preparedStatement.setString(9, broadcasterName);
                   preparedStatement.setInt(10, numOfStars);
                   preparedStatement.executeUpdate();   
                   System.out.println("\n Virayesh ba movafaghiat anjam shod\n");
                   connect.close();
               }
               catch(Exception ex){
                   ex.printStackTrace();
               }
             
            }
        
            }
         }
