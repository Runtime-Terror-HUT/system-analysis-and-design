
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;


public class Taghche {

    
    public static void main(String[] args) {
       
       User user = new User();
        
    }
}
