
import java.util.Random;

public class RandomNumber {
    //sakhtane yek adad random be tedad raghame delkhah
    public static String random(int digit){
        long m=(long) Math.pow(10, digit-1);        //10 be tavane tedade yeki kamtar az tedad arqam (shoroe baze)
        int random=new Random().nextInt((int) (9*m));       //eejade yek adade random ba saqfe 9*(10 be tavane digits-1)
        long number=m+ random;      //hasel adadist ke hasele jame ebteda va entehaye baze mibashad
        String randomStr=String.valueOf(number);        //tabdile adad be string baraye estefade dar text field ha
        return randomStr;
        //be onvane mesal baraye digit=4, hasel adadist beyne 1000 ta 9999 (9999=1000+(adadi random zire 9000)
    }
    
}

