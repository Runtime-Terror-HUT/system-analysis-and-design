/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Novin SOft
 */
public class showCategoryOfBook {
    public void showCategory(long bookID){
        long[] cats=new long[10];
        int i=0;
        try{
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver").newInstance();
            String url="jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
            Connection connect=DriverManager.getConnection(url);
            Statement state=connect.createStatement();
            String query="select * from booksOfCategories";
            ResultSet result=state.executeQuery(query);
            while(result.next()){
                if(result.getInt(2)==(bookID)){
                    cats[i]=result.getLong(1);
                    i++;
                }
                System.out.println();
            }
            state.close();
            connect.close();
        }
        catch(IllegalAccessException | InstantiationException | ClassNotFoundException | SQLException ex){
            ex.printStackTrace();
        }
        
        try{
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver").newInstance();
            String url="jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
            Connection connect=DriverManager.getConnection(url);
            Statement state=connect.createStatement();
            String query="select * from categories";
            ResultSet result=state.executeQuery(query);
            while(result.next()){
                for(int j=0; j<10; j++){
                    if(cats[j]==result.getLong(1)){
                        System.out.print(result.getString(2)+"\t");
                        cats[j]=0;
                    }
                    
                }
                    
            }
            state.close();
            connect.close();
        }
        catch(IllegalAccessException | InstantiationException | ClassNotFoundException | SQLException ex){
            ex.printStackTrace();
        }
        
        
    }
    
}
