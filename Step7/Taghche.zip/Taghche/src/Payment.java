/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

/**
 *
 * @author Novin SOft
 */
public class Payment {
    long price, orderID, finalPriceAfterDiscount, discountCode, discountPrecent;
    boolean isPriceInRial;
    String date, bookName, costumerUserName, type;
    long costId, productId;
    
    public void Payment(long productID, long costumerID, boolean priceInRial, String productType){
        costId=costumerID;
        productId=productID;
        type=productType;
        discountCode=0;
        isPriceInRial=priceInRial;
        boolean valid=false;
        Scanner input=new Scanner(System.in);
        System.out.print("do you have any discont code?(enter 1 for yes and 0 for no) :");
        int answer=input.nextInt();
        if(answer==1){
            valid=getDiscountCode(); 
        }
        showPaymentInfo(valid);
        int answer3=0;
        boolean finish=true;
        while(answer3!=1 && answer3!=2 && answer3!=3 && finish==true){
            System.out.print("Enter option number:");
            answer3=input.nextInt();
            if(answer3==1){
                ElectronicBook book = new ElectronicBook(this.costId,this.productId);
            }
            else if(answer3==2){
                boolean validNewCode=false;
                System.out.println("New code:");
                validNewCode=getDiscountCode();
                showPaymentInfo(validNewCode);
                System.out.print("Enter option number:");
                finish=false;
                answer3=input.nextInt();
            }
            else if(answer3==3){
                addBookToDatabase();
            }
            else
                System.out.println("Incorrect input! try again");
        }
        
        
    }
    
    public void showPaymentInfo(boolean valid){
        readBookInfo();        
        System.out.println("------------------------------------------");
        System.out.println("price of product:"+price+"\t"+"name of product:"+bookName);
        if(valid==true){
            calculateFinalPrice();
            System.out.println("Price after discount="+ finalPriceAfterDiscount);
        }
        System.out.println("------------------------------------------");
        System.out.println("1.cancel\n2.change discount code\n3.verify");
        System.out.println("------------------------------------------");
    }
    
    public boolean getDiscountCode(){
        boolean canceled=false;
        boolean validDiscountCode=false;
        Scanner input=new Scanner(System.in);
        int answer2;
        boolean valid=false;
            do{
                canceled=false;
                System.out.print("Enter your discount code:");
                discountCode=input.nextInt();
                validDiscountCode=checkDiscountCode(discountCode);
                if(validDiscountCode==true){
                    System.out.println("------------------------------------------");
                    System.out.println("discount precent:"+ discountPrecent);
                    valid=true;
                    calculateFinalPrice();
                }
                else{
                    System.out.print("incorrect discount code! do you wanna try another code?(1=yes and 0=no):");
                    answer2=input.nextInt();
                    if(answer2==0){
                        canceled=true;
                    }
                }
            }while(validDiscountCode==false && canceled==false);    
        
        return valid;
    }
    
    public void addBookToDatabase(){
        addToPaymentsTable();
        System.out.println("Purchased successfully!");
    }
    
    public long makePaymentID(){
       RandomNumber ID = new RandomNumber();
       long paymentID =Long.parseLong(ID.random(6));
       long finalID = checkExistence(paymentID);
       return finalID;
    }
    
    public long checkExistence(long authorId){
       String ID;
       boolean exist = false;
       try{
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver").newInstance();
            String url="jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
            Connection connect=DriverManager.getConnection(url);
            Statement state=connect.createStatement();
            String query="select * from payments";
            ResultSet result=state.executeQuery(query);
            while(result.next()){
                ID=result.getString(1);   
               if( ID.equals(authorId)){
                   exist = true;
                }
            }
            
            state.close();
            connect.close();
        }
        catch(IllegalAccessException | InstantiationException | ClassNotFoundException | SQLException ex){
            ex.printStackTrace();
        }
       if(exist == true){
           RandomNumber number = new RandomNumber();
           long id = Long.parseLong(number.random(6));
           checkExistence(id);
       } 
       return authorId;
   }
    
    public void addToPaymentsTable(){
        long payID= makePaymentID();
        type="text";
        try{
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver").newInstance();
            String url="jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
            
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String date="1/24/2022";
            String time="10:34";
            String query = "insert into payments(paymentID, costumerID, productID, productType, price, inRial,"
                    + "discount) " /*, dateOfPayment, timeOfPayment*/
                    + "values(%s, %s, %s, '%s', %s, %s, %s)";
            query = String.format(query, payID,costId,productId,type, price,isPriceInRial,discountPrecent/*, date, time*/);
            state.execute(query);
            state.close();
            connect.close();
        }
        catch(IllegalAccessException | InstantiationException | ClassNotFoundException | SQLException ex){
            ex.printStackTrace();
        }
    }
    
    public void readBookInfo(){
        try{
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver").newInstance();
            String url="jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
            Connection connect=DriverManager.getConnection(url);
            Statement state=connect.createStatement();
            String query="select * from textualBook";
            ResultSet result=state.executeQuery(query);
            while(result.next()){
                bookName=result.getString(2);
                price=result.getInt(4);   
            }
            state.close();
            connect.close();
        }
        catch(IllegalAccessException | InstantiationException | ClassNotFoundException | SQLException ex){
            ex.printStackTrace();
        }
    }
    
    public boolean checkDiscountCode(long dCount){
        boolean validCode=false;
        long code;
        try{
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver").newInstance();
            String url="jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
            Connection connect=DriverManager.getConnection(url);
            Statement state=connect.createStatement();
            String query="select * from discountCodes";
            ResultSet result=state.executeQuery(query);
            while(result.next()){
                code=result.getLong(1);
                if(code==discountCode){
                    discountPrecent=result.getInt(2);
                    validCode=true;
                }
            }
            state.close();
            connect.close();
        }
        catch(IllegalAccessException | InstantiationException | ClassNotFoundException | SQLException ex){
            ex.printStackTrace();
        }
        
        return validCode;
    }
    
    public void calculateFinalPrice(){
        long pricetmp=price;
        long prcecnttmp=discountPrecent;
        long disPrice=(price*discountPrecent)/100;
        finalPriceAfterDiscount=price-disPrice;
    }
}
