
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import static javafx.application.Platform.exit;


public class ElectronicBook {
    
    private long costumerId;
    private long bookId;
    private String bookName;
    
    public ElectronicBook(long costumerId, long bookId,String bookName){
        
        this.costumerId = costumerId;
        this.bookId = bookId;
        this.bookName = bookName;
        menu();
        
    }
    public ElectronicBook(long costumerId, long bookId){
        this.costumerId = costumerId;
        this.bookName = bookName;
        menu();
    }
 
    public void menu(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("\nGhast darid ba in ketab che konid?\n1-namayesh jozyiat\n2-namayesh nazarat\n3-nmayesh ketab hay hamin nevisande"
                + "\n4-kharid ketab\n5-neshan kardan ketab\n6-khoroj az hesab");
        int choice = scanner.nextInt();
        switch(choice){
            case 1:
                showDetails(this.bookId);
                break;
            case 2:
                showComments();
                break;
            case 3:
                findBook(this.bookId);
                break;
            case 4:
                Payment pay=new Payment();
                pay.Payment(this.bookId, this.costumerId, true , "text");
                break;
            case 5:
                markForPocket mark = new markForPocket();
                mark.mark(this.bookId, this.costumerId, this.bookName);
                break;
            case 6:
                while(true){
                    System.out.println("\naya az khoroj etminan darid?\n1-bale\n2-kheir\n");
                    int cho = scanner.nextInt();
                    if(cho == 1){
                        exit();
                        break;
                    }
                    else if(cho == 2){
                        System.out.println("\namaliyat motevagef shod.\n");
                        menu();
                        break;
                    }
                    else{
                        System.out.println("\nlotfa yek adad motabar vared konid:\n");
                    }
                 
                } 
                break;
        }
        
                
    }
    
    
    
    public void showComments(){
        
        System.out.println("\nnazar hay in ketab:\n");
         
        try{
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver").newInstance();
            String url="jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
            Connection connect=DriverManager.getConnection(url);
            Statement state=connect.createStatement();
            String query="select * from comments WHERE bookID = %s";
            query = String.format(query, this.bookId); 
            ResultSet result=state.executeQuery(query);
            while(result.next()){
                
               System.out.print("nam karbar:" +result.getString("userName") + "    ");
               System.out.print("nazar karbar:" + result.getString("commentText") + "    ");
               System.out.print("saat nazar:" + result.getString("timeOfComment") + "    ");
               System.out.println("tarikh nazar:" + result.getString("dateOfComment") + "    \n");
               
            }
            
            state.close();
            connect.close();
        }
        catch(IllegalAccessException | InstantiationException | ClassNotFoundException | SQLException ex){
            ex.printStackTrace();
        }
        menu();
    }
    
      public void findBookId(String bookName){
        
        long bookId = 0;
        
                
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver").newInstance();
            String url = "jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "select * from allProducts  WHERE bookName = '%s' ";
            query = String.format(query, bookName);
            ResultSet result = state.executeQuery(query);
            while (result.next()) {
                bookId = result.getLong("productID");

            }

            state.close();
            connect.close();
        } catch (IllegalAccessException | InstantiationException | ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        }
        showDetails(bookId);
    }
     
      
    public void showDetails(long bookId){
         
        String type = "";
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver").newInstance();
            String url = "jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "select * from allProducts  WHERE productID = %s ";
            query = String.format(query, bookId);
            ResultSet result = state.executeQuery(query);
            while (result.next()) {
               if(result.getString("type").equals("textual"))
                     type = "textual";
              else
                     type = "audio";

            }

            state.close();
            connect.close();
        } catch (IllegalAccessException | InstantiationException | ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        }
          
                  
          if(type.equals("textual"))
              showTextualBook(bookId);
          else if(type.equals("audio"))
               showAudioBook(bookId);
          
          
    }
    
    public void showTextualBook(long bookId){
        
         
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver").newInstance();
            String url = "jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "select * from textualBook  WHERE bookID = %s ";
            query = String.format(query, bookId);
            ResultSet result = state.executeQuery(query);
            while (result.next()) {
                System.out.println("nam ketab:" + result.getString("bookName")+"\n");
                System.out.println("tozihati rajeb ketab:" + result.getString("bookIntro") + "\n");
                System.out.println("gheymat:" + result.getString("price") + "\n");
                System.out.println("format:" + result.getString("format") + "\n");
                System.out.println("gheymat noskhe chapi:" + result.getString("priceOfPrintedVersion") + "\n");
                System.out.println("nasher:" + result.getString("publisher")+ "\n");
                System.out.println("hajm file:" + result.getString("fileSize") + "\n");
                System.out.println("tedad safahat ketab:"+ result.getString("numberOfPages") + "\n");
                System.out.println("sal enteshar:"+ result.getString("publishYear")+ "\n");
                System.out.println("shomare shabk:"+ result.getString("ISBN") + "\n");
                System.out.println("nam nevisande:"+ result.getString("authorName") + "\n");
                System.out.println("nam nasher:"+ result.getString("translatorName") + "\n");
                System.out.println("tedad setare:"+ result.getString("numberOfStars") + "\n");
                System.out.print("noskhey soti:");
                if(result.getBoolean("availableAudioVersion") == true)
                    System.out.println("darad\n");
                else
                    System.out.println("nadarea\n");
                System.out.print("dar taghche binahayat vojod:");
                if(result.getBoolean("validInUnlimited") == true)
                    System.out.println("darad\n");
                else
                    System.out.println("nadarad\n");
               
                
                        

            }

            state.close();
            connect.close();
        } catch (IllegalAccessException | InstantiationException | ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        }
        
        menu();
    }
    
    public void showAudioBook(long bookId){
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver").newInstance();
            String url = "jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "select * from audioBook  WHERE audioBookID = %s ";
            query = String.format(query, bookId);
            ResultSet result = state.executeQuery(query);
            while (result.next()) {
                System.out.println("nam ketab:" + result.getString("bookName")+"\n");
                System.out.println("tozihati rajeb ketab:" + result.getString("bookIntro") + "\n");
                System.out.println("gheymat:" + result.getString("price") + "\n");
                System.out.println("format:" + result.getString("fileFormat") + "\n");
                System.out.println("nasher:" + result.getString("publisher")+ "\n");
                System.out.println("hajm file:" + result.getString("fileSize") + "\n");
                System.out.println("tedad safahat ketab:"+ result.getString("timeOfAudio") + "\n");
                System.out.println("sal enteshar:"+ result.getString("publishYear")+ "\n");
                System.out.println("nam nevisande:"+ result.getString("authorName") + "\n");
                System.out.println("nam nasher:"+ result.getString("translatorName") + "\n");
                System.out.println("nam gooyande:"+ result.getString("broacasterName") + "\n");
                System.out.println("tedad setare:"+ result.getString("numberOfStars") + "\n");
                System.out.print("noskhey soti:");
                if(result.getBoolean("availableElectronicVersion") == true)
                    System.out.println("darad\n");
                else
                    System.out.println("nadarea\n");
                System.out.print("ghabeliyat zakhire kardan:");
                if(result.getBoolean("allowedToShareOrSave") == true)
                    System.out.println("darad\n");
                else
                    System.out.println("nadarad\n");
               
                
                        

            }
            state.close();
            connect.close();
        } catch (IllegalAccessException | InstantiationException | ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        }
        
        menu();
    
    }
     public void findBook(long bookId){
         
                 
         
        String type = "";
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver").newInstance();
            String url = "jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "select * from allProducts  WHERE productID = %s ";
            query = String.format(query, bookId);
            ResultSet result = state.executeQuery(query);
            while (result.next()) {
               if(result.getString("type").equals("textual"))
                     type = "textual";
              else
                     type = "audio";

            }

            state.close();
            connect.close();
        } catch (IllegalAccessException | InstantiationException | ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        }
          
              
           findAuthorName(type);
          
          
    }
    public void findAuthorName(String type){
    
        String authorName = "";
         
        if(type.equals("textual")){
           
        
            try{
                Class.forName("net.ucanaccess.jdbc.UcanaccessDriver").newInstance();
                String url="jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
                Connection connect=DriverManager.getConnection(url);
                Statement state=connect.createStatement();
                String query="select * from textualBook WHERE bookID = %s";
                query = String.format(query, this.bookId); 
                ResultSet result=state.executeQuery(query);
                while(result.next()){
                    authorName = result.getString("authorName");
               
                }
            
                state.close();
                connect.close();
            }
            catch(IllegalAccessException | InstantiationException | ClassNotFoundException | SQLException ex){
                ex.printStackTrace();
            }
        }
        else if(type.equals("audio")){
              try{
                Class.forName("net.ucanaccess.jdbc.UcanaccessDriver").newInstance();
                String url="jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
                Connection connect=DriverManager.getConnection(url);
                Statement state=connect.createStatement();
                String query="select * from audioBook WHERE bookID = %s";
                query = String.format(query, this.bookId); 
                ResultSet result=state.executeQuery(query);
                while(result.next()){
                    authorName = result.getString("authorName");
               
                }
            
                state.close();
                connect.close();
            }
            catch(IllegalAccessException | InstantiationException | ClassNotFoundException | SQLException ex){
                ex.printStackTrace();
            }  
                }
            
        
        
       showBooksOfAuthor(authorName);
    }
    
    
    public void showBooksOfAuthor(String authorName){
       
      
          try{
                Class.forName("net.ucanaccess.jdbc.UcanaccessDriver").newInstance();
                String url="jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
                Connection connect=DriverManager.getConnection(url);
                Statement state=connect.createStatement();
                String query="select * from textualBook WHERE authorName = '%s'";
                query = String.format(query, authorName); 
                ResultSet result=state.executeQuery(query);
                while(result.next()){
                    System.out.println(result.getString("bookName"));
               
                }
            
                state.close();
                connect.close();
            }
            catch(IllegalAccessException | InstantiationException | ClassNotFoundException | SQLException ex){
                ex.printStackTrace();
            }
        
        try{
                Class.forName("net.ucanaccess.jdbc.UcanaccessDriver").newInstance();
                String url="jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
                Connection connect=DriverManager.getConnection(url);
                Statement state=connect.createStatement();
                String query="select * from audioBook WHERE authorName = '%s'";
                query = String.format(query, authorName); 
                ResultSet result=state.executeQuery(query);
                while(result.next()){
                    System.out.println(result.getString("bookName") );
               
                }
            
                state.close();
                connect.close();
            }
            catch(IllegalAccessException | InstantiationException | ClassNotFoundException | SQLException ex){
                ex.printStackTrace();
            }
       Scanner scanner = new Scanner(System.in);
       System.out.println("\nbaray didan jozyiat ketab nam on ra be dorosti bared konid(baray khoroj '0' ra vared konid):\n");
       String bookName = scanner.nextLine();
       if(bookName.equals("0")){
           menu();
       }
       else
          findBookId(bookName);
    }
    
  
    
}
