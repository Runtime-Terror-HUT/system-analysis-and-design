/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Novin SOft
 */
public class dislikeAComment {
public void likeComment(int commentID){
        int numberOfDislikes=0;
        try{
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver").newInstance();
            String url="jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
            Connection connect=DriverManager.getConnection(url);
            Statement state=connect.createStatement();
            String query="select * from comments";
            ResultSet result=state.executeQuery(query);
            while(result.next()){
                if(result.getInt(2)==(commentID));
                    numberOfDislikes=result.getInt(8);
            }
            state.close();
            connect.close();
        }
        catch(IllegalAccessException | InstantiationException | ClassNotFoundException | SQLException ex){
            ex.printStackTrace();
        }
        
        numberOfDislikes++;
        
        try{//barresie dade haye mojud dar database
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver").newInstance();
            String url="jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
            Connection connect=DriverManager.getConnection(url);
            Statement state=connect.createStatement();
            String query="update comments set dislikesNumber=%s where commentID=%s";
            query=String.format(query, numberOfDislikes, commentID);
            state.execute(query);
            state.close();
            connect.close();           
        }
        catch(IllegalAccessException | InstantiationException | ClassNotFoundException | SQLException ex){
            ex.printStackTrace();
        }   
        
        System.out.println("you disliked this comment");
        
    }   

}
