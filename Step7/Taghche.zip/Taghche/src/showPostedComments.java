/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;

/**
 *
 * @author Novin SOft
 */
public class showPostedComments {
    public void showComment(long costumerID){
        String text="", userName="", time="", date="", bookName="";
        int numberOfLikes=0, numberOfDislikes=0;
        int costID=0;
        long id;
        
        try{
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver").newInstance();
            String url="jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
            Connection connect=DriverManager.getConnection(url);
            Statement state=connect.createStatement();
            String query="select * from comments";
            ResultSet result=state.executeQuery(query);
            while(result.next()){
                id=result.getLong(1);
                if(id==costumerID){
                    bookName=result.getString(6);
                    text=result.getString(3);
                    userName=result.getString(4);   
                    time=result.getString(10);
                    date=result.getString(9);
                    numberOfLikes=result.getInt(7);
                    numberOfDislikes=result.getInt(8);
                    System.out.println("book name:"+bookName+"\ncomment text: "+ text+"\nuser name: "+ userName+ "\ntime: "+time
                            +"\ndate:"+date+"\nnumber of likes: "+numberOfLikes+"\nnumber of dislikes: "+
                            numberOfDislikes);

                    System.out.println("--------------------------------------");
                }
            }
            state.close();
            connect.close();
        }
        catch(IllegalAccessException | InstantiationException | ClassNotFoundException | SQLException ex){
            ex.printStackTrace();
        }
        
    }
    
    
}
