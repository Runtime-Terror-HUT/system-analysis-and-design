
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import static javafx.application.Platform.exit;


public class CustomerPage {
    
   private String username;
   private String email;
   private String pass;
   private String phoneNumber;
   private  boolean isRegistered = false;
   private long customerID;
   
   
   public CustomerPage(){
       menu();
   }
   
   public void menu(){
       Scanner scanner = new Scanner(System.in);
       System.out.println("\nGozine Mord Nazar Ra Entekhab Konid:\n1-vorood be hesab karbari\n2-sabt nam\n3-bazgasht\n4-khoroj az barname\n");
       int choice = scanner.nextInt();
       switch(choice){
           case 1:
               login();
               break;
            case 2:
               signUp();
               break;
            case 3:
                User user = new User();
                break;
            case 4:
                while(true){
                    System.out.println("\naya az khoroj motmaen hastid?\n1-bale\n2-kheir\n");
                    int c = scanner.nextInt();
                    if(c == 1){
                        exit();
                        break;
                    }
                    else if(c == 2){
                        System.out.println("\namaliyat motevagef shod.\n");
                         menu();
                        break;
                    }
                    else{
                        System.out.println("\nlotfan yek adad motabar vared koni:\n");
                    }
                }
                break;
            default :
                System.out.println("\nlotfa yek adad motabar vared konid:\n");
                menu();
                
       }
   }
   
   public void login(){
       
       Scanner scanner = new Scanner(System.in);
       System.out.println("\nshomare telephon hamrah ya email ra vared konid:\n1-shomare telephoe\n2-email\n3-bazgasht\n4-khoroj\n");
       int choice = scanner.nextInt();
       switch(choice){
           case 1:
               enterWithPhoneNumber();
               break;
           case 2:
               enterWithEmail();
               break;
           case 3:
               menu();
               break;
           case 4:
                while(true){
                    System.out.println("\naya az khoroj motmaen hastid?\n1-bale\n2-kheir\n");
                    int c = scanner.nextInt();
                    if(c == 1){
                        exit();
                        break;
                    }
                    else if(c == 2){
                        System.out.println("\namaliyat motevagef shod.\n");
                        login();
                        break;
                     }
                    else{
                        System.out.println("\nlotfan yek adad motabar vared koni:\n");
                    }
                }
                break;
           default:
               System.out.println("\nlotfa yek adad motabar vared konid:\n");
              login();
               
       }  
   }
   
    public void enterWithPhoneNumber(){
       String phone ="" , password = "";
    
       Scanner scanner = new Scanner(System.in);
       System.out.println("\nshomare khod ra vared konid(baray khoroj 0 ra vared konid):\n");
       this.phoneNumber = scanner.nextLine();
       if(this.phoneNumber.equals("0")){
           System.out.println("\namaliyat motevagef shod.\n");
           login();
       }
       else {
            System.out.println("\nramz khod ra vared konid(baray khoroj 0 ra vared konid):\n");
            this.pass = scanner.nextLine();
            if(this.pass.equals("0") ){
                System.out.println("\namaliyat motevagef shod.\n");
                login();
            }
       }
     
     try{
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver").newInstance();
            String url="jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
            Connection connect=DriverManager.getConnection(url);
            Statement state=connect.createStatement();
            String query="select * from costumer";
            ResultSet result=state.executeQuery(query);
            while(result.next()){
                phone=result.getString("phoneNumber");    
                password=result.getString("password");
              
                if(phone.equals(phoneNumber) && password.equals(pass)){
                    isRegistered = true;
                    this.customerID = result.getLong("costumerID");
                }
                
            }
            
            state.close();
            connect.close();
        }
        catch(IllegalAccessException | InstantiationException | ClassNotFoundException | SQLException ex){
            ex.printStackTrace();
        }
        if(isRegistered == true){
            System.out.println("\nVorod mofagiyat amiz.khosh amadid.\n");
            
            
          UserProfile page = new UserProfile(customerID);
            
        }
        else{
            System.out.println("\nshomare telephone ya ramz eshtebah ast\n.");
            enterWithPhoneNumber();
        }
   }
    
     public void enterWithEmail(){
       String emmail ="" , password = "";
       
       Scanner scanner = new Scanner(System.in);
       System.out.println("\nemail khod ra vared konid(baray khoroj 0 ra vared konid):\n");
       this.email = scanner.nextLine();
       if(this.email.equals("0")){
           System.out.println("\namaliyat motevagef shod.\n");
           login();
       }
       else {
            System.out.println("\nramz khod ra vared konid(baray khoroj 0 ra vared konid):\n");
            this.pass = scanner.nextLine();
            if(this.pass.equals("0") ){
                System.out.println("\namaliyat motevagef shod.\n");
                login();
            }
       }
          
     try{
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver").newInstance();
            String url="jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
            Connection connect=DriverManager.getConnection(url);
            Statement state=connect.createStatement();
            String query="select * from costumer";
            ResultSet result=state.executeQuery(query);
            while(result.next()){
                emmail=result.getString(4);   
                password=result.getString(3);
                
                if(emmail.equals(email) && password.equals(pass)){
                
                    isRegistered = true;
                    this.customerID = result.getLong("costumerID");
                }
                    
            }
            
            state.close();
            connect.close();
        }
        catch(IllegalAccessException | InstantiationException | ClassNotFoundException | SQLException ex){
            ex.printStackTrace();
        }
        if(isRegistered == true){
            System.out.println("\nVorod mofagiyat amiz.khosh amadid.\n");
             UserProfile page = new UserProfile(customerID); 
            
        }
        else{
            System.out.println("\nemail telephone ya ramz eshtebah ast.");
            enterWithPhoneNumber();
        }
   }
   
   public void signUp(){
       RandomNumber number = new RandomNumber();
       long customerId =Long.parseLong(number.random(5));
       long provenCostumerId = checkExistence(customerId);
       Scanner scanner = new Scanner(System.in);
       System.out.println("\nnam karbari khod ra vared konid(baray khoroj 0 ra vared konid):\n");
       this.username = scanner.nextLine();
       if(this.username.equals("0")){
           System.out.println("\namaliyat motevagef shod.\n");
           menu();
       }
       else{
            System.out.println("\nemail khod ra vared konid(baray khoroj 0 ra vared konid):\n");
            this.email = scanner.nextLine();
            if(this.email.equals("0")){
                System.out.println("\namaliyat motevagef shod.\n");
                menu();
            }
            else{
                System.out.println("\nshomare khod ra vared konid(baray khoroj 0 ra vared konid):\n");
                this.phoneNumber = scanner.nextLine();
                if(this.phoneNumber.equals("0")){
                    System.out.println("\namaliyat motevagef shod.\n");
                    menu();
                }
                else{
                    System.out.println("\nramz khod ra vard konid(baray khoroj 0 ra vared konid):\n");
                    this.pass = scanner.nextLine();
                    if(this.pass.equals("0")){
                        System.out.println("\namaliyat motevagef shod.\n");
                        menu();
                    }
                }
            }
       }
      
       try{
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver").newInstance();
            String url="jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "insert into costumer(costumerID,username,email,phoneNumber,password, accountCredit)"
                    + " values(%s,'%s','%s','%s','%s',%s)";
            query = String.format(query,customerId,username,email,phoneNumber,pass,0);
            state.execute(query);
            state.close();
            connect.close();
        }
        catch(IllegalAccessException | InstantiationException | ClassNotFoundException | SQLException ex){
            ex.printStackTrace();
        }
              System.out.println("\nSabt nam ba movafaghiat anjam shod\nbe taghche khosh amadid :) \n");
               UserProfile page = new UserProfile(customerID);
       
        
   }
   
   public long checkExistence(long customerId){
       String customerid;
       boolean exist = false;
       try{
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver").newInstance();
            String url="jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
            Connection connect=DriverManager.getConnection(url);
            Statement state=connect.createStatement();
            String query="select * from costumer";
            ResultSet result=state.executeQuery(query);
            while(result.next()){
                customerid=result.getString(4);   
               if( customerid.equals(customerId)){
                   exist = true;
                }
                    
            }
            
            state.close();
            connect.close();
        }
        catch(IllegalAccessException | InstantiationException | ClassNotFoundException | SQLException ex){
            ex.printStackTrace();
        }
       if(exist == true){
           RandomNumber number = new RandomNumber();
           long id = Long.parseLong(number.random(5));
           checkExistence(id);
       } 
       return customerId;
   }
}
