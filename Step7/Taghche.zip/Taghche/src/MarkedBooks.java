
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import static javafx.application.Platform.exit;


public class MarkedBooks {
    
    private String bookName;
    private long bookID;
    private String date;
    private long customerID;
 
    
    public MarkedBooks(long customerID){
       this.customerID = customerID;
       showMarkedBook();
    }
    
    
    public void showMarkedBook(){
       int index = 1;
        System.out.println("ketabhay neshan gozari shode:\n");
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver").newInstance();
            String url = "jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "select * from favorites  WHERE costumerID = '%s' ";
            query = String.format(query, Long.toString(this.customerID));
            ResultSet result = state.executeQuery(query);
            while (result.next()) {
                System.out.println(index++ + "-" + result.getString("bookName")+"\n");

            }

            state.close();
            connect.close();
        } catch (IllegalAccessException | InstantiationException | ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        }

        menu();
        
    }
    
    public void findBookId(String bookName){
        
        long bookId = 0;
        
                
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver").newInstance();
            String url = "jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "select * from favorites  WHERE bookName = '%s' ";
            query = String.format(query, bookName);
            ResultSet result = state.executeQuery(query);
            while (result.next()) {
                bookId = result.getLong("bookID");

            }

            state.close();
            connect.close();
        } catch (IllegalAccessException | InstantiationException | ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        }
        showDetails(bookId);
    }
    
    public void menu(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("\n1-didan joziyat ketab\n2-namayesh ketab hay neshan shode\n3-bazgasht\n4-khoroj az barname\n");
        int choice = scanner.nextInt();
        switch(choice){
            case 1:
                Scanner scan = new Scanner(System.in);
                System.out.println("baray didan jozyiat nam ketab mored nazar ra be dorosti vared konid:\n");
                String bookName = scan.nextLine();
                findBookId(bookName);
                break;
            case 2:
                showMarkedBook();
                break;
            case 3:
                //to do
                break;
                
            case 4:
                while(true){
                    System.out.println("\naya az khoroj etminan darid?\n1-bale\n2-kheir\n");
                    int cho = scanner.nextInt();
                    if(cho == 1){
                        exit();
                        break;
                    }
                    else if(cho == 2){
                        System.out.println("\namaliyat motevagef shod.\n");
                        showMarkedBook();
                        break;
                    }
                    else{
                        System.out.println("\nlotfa yek adad motabar vared konid:\n");
                    }
                 
                } 
                break;
            default :
                System.out.println("lotfan yek gozinye motabar vared koni:\n");
                menu();
                        
                        
        }
    }
    
    public void showDetails(long bookId){
         
         String type = "";
          try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver").newInstance();
            String url = "jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "select * from allProducts  WHERE productID = %s ";
            query = String.format(query, bookId);
            ResultSet result = state.executeQuery(query);
            while (result.next()) {
               if(result.getString("type").equals("textual"))
                     type = "textual";
              else
                     type = "audio";

            }

            state.close();
            connect.close();
        } catch (IllegalAccessException | InstantiationException | ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        }
          
                  
          if(type.equals("textual"))
              showTextualBook(bookId);
          else if(type.equals("audio"))
               showAudioBook(bookId);
          
          
    }
    
    public void showTextualBook(long bookId){
        
         
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver").newInstance();
            String url = "jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "select * from textualBook  WHERE bookID = %s ";
            query = String.format(query, bookId);
            ResultSet result = state.executeQuery(query);
            while (result.next()) {
                System.out.println("nam ketab:" + result.getString("bookName")+"\n");
                System.out.println("tozihati rajeb ketab:" + result.getString("bookIntro") + "\n");
                System.out.println("gheymat:" + result.getString("price") + "\n");
                System.out.println("format:" + result.getString("format") + "\n");
                System.out.println("gheymat noskhe chapi:" + result.getString("priceOfPrintedVersion") + "\n");
                System.out.println("nasher:" + result.getString("publisher")+ "\n");
                System.out.println("hajm file:" + result.getString("fileSize") + "\n");
                System.out.println("tedad safahat ketab:"+ result.getString("numberOfPages") + "\n");
                System.out.println("sal enteshar:"+ result.getString("publishYear")+ "\n");
                System.out.println("shomare shabk:"+ result.getString("ISBN") + "\n");
                System.out.println("nam nevisande:"+ result.getString("authorName") + "\n");
                System.out.println("nam nasher:"+ result.getString("translatorName") + "\n");
                System.out.println("tedad setare:"+ result.getString("numberOfStars") + "\n");
                System.out.print("noskhey soti:");
                if(result.getBoolean("availableAudioVersion") == true)
                    System.out.println("darad\n");
                else
                    System.out.println("nadarea\n");
                System.out.print("dar taghche binahayat vojod:");
                if(result.getBoolean("validInUnlimited") == true)
                    System.out.println("darad\n");
                else
                    System.out.println("nadarad\n");
               
                
                        

            }

            state.close();
            connect.close();
        } catch (IllegalAccessException | InstantiationException | ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        }
        
        menu();
    }
    
    public void showAudioBook(long bookId){
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver").newInstance();
            String url = "jdbc:ucanaccess://C:/Taghche database/taghcheDatabase.mdb";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "select * from audioBook  WHERE audioBookID = %s ";
            query = String.format(query, bookId);
            ResultSet result = state.executeQuery(query);
            while (result.next()) {
                System.out.println("nam ketab:" + result.getString("bookName")+"\n");
                System.out.println("tozihati rajeb ketab:" + result.getString("bookIntro") + "\n");
                System.out.println("gheymat:" + result.getString("price") + "\n");
                System.out.println("format:" + result.getString("fileFormat") + "\n");
                System.out.println("nasher:" + result.getString("publisher")+ "\n");
                System.out.println("hajm file:" + result.getString("fileSize") + "\n");
                System.out.println("tedad safahat ketab:"+ result.getString("timeOfAudio") + "\n");
                System.out.println("sal enteshar:"+ result.getString("publishYear")+ "\n");
                System.out.println("nam nevisande:"+ result.getString("authorName") + "\n");
                System.out.println("nam nasher:"+ result.getString("translatorName") + "\n");
                System.out.println("nam gooyande:"+ result.getString("broacasterName") + "\n");
                System.out.println("tedad setare:"+ result.getString("numberOfStars") + "\n");
                System.out.print("noskhey soti:");
                if(result.getBoolean("availableElectronicVersion") == true)
                    System.out.println("darad\n");
                else
                    System.out.println("nadarea\n");
                System.out.print("ghabeliyat zakhire kardan:");
                if(result.getBoolean("allowedToShareOrSave") == true)
                    System.out.println("darad\n");
                else
                    System.out.println("nadarad\n");
               
                
                        

            }
            state.close();
            connect.close();
        } catch (IllegalAccessException | InstantiationException | ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        }
        
        menu();
    }
}
