
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import static javafx.application.Platform.exit;


public class User {
    
  
  
    public User(){
      
       menu();   
   }
   
   public void menu(){
       
       Scanner scanner = new Scanner(System.in);
       
       
       System.out.println("               TAGHCHE             \n\n"
               + "  Be ketab Forooshi Online Taghche Khosh Amadid            \n\n"
               + "Gozine Mord Nazar Ra Entekhab Konid:\n"
               + "1-moshtari\n2-nevisande\n3-khoroj az barname\n");
       int choice = scanner.nextInt();
       
       switch(choice){
           case 1:
               CustomerPage cPage = new CustomerPage();
               break;
           case 2:
              AuthorPage aPage = new AuthorPage();
               break;
           case 3:
               while(true){
               System.out.println("\naya az khoroj etminan darid?\n1-bale\n2-kheir\n");
               int cho = scanner.nextInt();
               if(cho == 1){
                    exit();
                    break;
               }
               else if(cho == 2){
                   System.out.println("\namaliyat motevagef shod.\n");
                   menu();
                   break;
               }
               else{
                  System.out.println("\nlotfa yek adad motabar vared konid:\n");
               }
                   
                   
               }      
               break;
           default :
               System.out.println("\nlotfa yek adad motabar vared konid:\n");
               menu();
       }
       
     
   }
   
}
  
   
   
  
   
  
   
  
   
  